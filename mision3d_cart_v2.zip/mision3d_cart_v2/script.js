const PRODUCTS=[
{id:'f1',name:'Calendario Formula 1',price:15990,img:'img/calendario-f1.png'},
{id:'bey',name:'Caja Beyblade',price:18990,img:'img/caja-beyblade.png'},
{id:'pet',name:'Figura Mascota',price:24990,img:'img/mascota.png'},
{id:'poke',name:'Pokebola',price:7990,img:'img/pokebola.png'},
{id:'key',name:'Llavero',price:4990,img:'img/llavero.png'},
];
const $=q=>document.querySelector(q),$$=q=>document.querySelectorAll(q),money=v=>v.toLocaleString('es-CL',{style:'currency',currency:'CLP'});
let cart=JSON.parse(localStorage.getItem('cart')||'[]');
function save(){localStorage.setItem('cart',JSON.stringify(cart))}
function badge(){ $('#cartCount').textContent=cart.reduce((a,i)=>a+i.qty,0)}
function openCart(){ $('#cartDrawer').classList.add('open');$('#overlay').classList.add('show');render() }
function closeCart(){ $('#cartDrawer').classList.remove('open');$('#overlay').classList.remove('show') }
function add(id){let it=cart.find(x=>x.id===id);if(it)it.qty++;else cart.push({id,qty:1});save();badge()}
function qty(id,d){let i=cart.findIndex(x=>x.id===id);if(i<0)return;cart[i].qty+=d;if(cart[i].qty<=0)cart.splice(i,1);save();render();badge()}
function del(id){cart=cart.filter(x=>x.id!==id);save();render();badge()}
function render(){let c=$('#cartItems');c.innerHTML='';let t=0;if(cart.length===0){c.innerHTML='<p>Carrito vacío</p>'}else{cart.forEach(it=>{let p=PRODUCTS.find(x=>x.id===it.id),sub=p.price*it.qty;t+=sub;let e=document.createElement('div');e.className='cart-item';e.innerHTML=`<img src="${p.img}"><div><div>${p.name}</div><div>${money(p.price)} c/u</div><div class="qty"><button>-</button><span>${it.qty}</span><button>+</button><button style="margin-left:6px">🗑️</button></div></div><strong>${money(sub)}</strong>`;let[bm,,bp,bd]=e.querySelectorAll('button');bm.onclick=()=>qty(it.id,-1);bp.onclick=()=>qty(it.id,1);bd.onclick=()=>del(it.id);c.appendChild(e)})}$('#cartTotal').textContent=money(t)}
function checkout(){if(cart.length===0)return alert('Tu carrito está vacío');$('#checkoutModal').classList.add('show')}
function confirmCheckout(){let name=$('#inputName').value.trim(),region=$('#inputRegion').value.trim(),notes=$('#inputNotes').value.trim();if(!name||!region)return alert('Completa nombre y región');let msg='Hola! Quiero hacer este pedido:%0A%0A';cart.forEach(it=>{let p=PRODUCTS.find(x=>x.id===it.id);msg+=`• ${p.name} x${it.qty} (${money(p.price)} c/u)%0A`});let total=cart.reduce((a,it)=>{let p=PRODUCTS.find(x=>x.id===it.id);return a+p.price*it.qty},0);msg+=`%0ATotal: ${money(total)}%0A%0ADatos:%0ANombre: ${name}%0ARegión: ${region}%0ANotas: ${notes}`;let phone='569XXXXXXXX';window.open(`https://wa.me/${phone}?text=${msg}`,'_blank');$('#checkoutModal').classList.remove('show')}
document.addEventListener('DOMContentLoaded',()=>{badge();$$('.add').forEach(b=>b.onclick=()=>add(b.dataset.id));$('#openCart').onclick=openCart;$('#closeCart').onclick=closeCart;$('#overlay').onclick=closeCart;$('#checkout').onclick=checkout;$('#clearCart').onclick=()=>{cart=[];save();render();badge()};$('#confirmCheckout').onclick=confirmCheckout;$('#cancelCheckout').onclick=()=>$('#checkoutModal').classList.remove('show')})
